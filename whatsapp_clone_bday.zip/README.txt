
WHATSAPP-STYLE BIRTHDAY (code clone)
------------------------------------
What this package contains:
- index.html : single-file project that recreates a WhatsApp-like animated greeting.
- The page uses 3 canvas layers:
    * glitter (tiny fast twinkling particles)
    * bokeh   (soft floating blobs for depth)
    * fire    (fireworks shown at blast)
How to use:
1) Download and extract this folder.
2) Open index.html in VS Code or double-click it in your file manager.
3) If you want the video background instead of canvas, replace background by a video file named 'bg.mp4' in same folder and remove/hide canvas layers as desired.
4) To edit texts, open index.html and change:
   - <h1 id="headline">...</h1>
   - <p id="tagline">...</p>
   - <div id="celebrate">...</div>
   - <p id="footnote">...</p>
Notes:
- Countdown is set to next midnight IST (India Standard Time).
- Fireworks auto trigger when countdown reaches zero.
